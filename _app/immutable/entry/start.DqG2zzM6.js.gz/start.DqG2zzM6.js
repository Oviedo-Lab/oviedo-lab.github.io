import{a as t}from"../chunks/entry.C3BZUO4m.js";export{t as start};
