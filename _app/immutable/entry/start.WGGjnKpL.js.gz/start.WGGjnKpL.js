import{a as t}from"../chunks/entry.CDjcRu5F.js";export{t as start};
