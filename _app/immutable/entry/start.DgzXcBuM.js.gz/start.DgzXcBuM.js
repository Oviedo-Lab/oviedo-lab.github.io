import{a as t}from"../chunks/entry.qXdey0Pa.js";export{t as start};
