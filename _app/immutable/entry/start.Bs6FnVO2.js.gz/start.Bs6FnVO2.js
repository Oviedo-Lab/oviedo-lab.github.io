import{a as t}from"../chunks/entry.B34LAOYs.js";export{t as start};
