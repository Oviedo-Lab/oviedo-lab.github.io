import{a as t}from"../chunks/entry.DCRrpRxF.js";export{t as start};
