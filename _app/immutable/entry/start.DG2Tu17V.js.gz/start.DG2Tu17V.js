import{a as t}from"../chunks/entry.Dsf036GI.js";export{t as start};
