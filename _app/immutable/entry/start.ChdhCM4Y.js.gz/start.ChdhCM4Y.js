import{a as t}from"../chunks/entry.BNaMO-wy.js";export{t as start};
