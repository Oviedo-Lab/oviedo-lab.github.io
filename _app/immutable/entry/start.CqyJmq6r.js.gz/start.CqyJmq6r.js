import{a as t}from"../chunks/entry.BZDB158e.js";export{t as start};
