import{a as t}from"../chunks/entry.DS4K27xF.js";export{t as start};
