import{a as t}from"../chunks/entry.Ccn6hl72.js";export{t as start};
