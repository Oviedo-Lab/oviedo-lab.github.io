import{a as t}from"../chunks/entry.6aKkPned.js";export{t as start};
