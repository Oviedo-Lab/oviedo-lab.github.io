import{a as t}from"../chunks/entry.CmpvB4cf.js";export{t as start};
