import{a as t}from"../chunks/entry.D9kRiZxV.js";export{t as start};
