import{a as t}from"../chunks/entry.SM3nFUis.js";export{t as start};
