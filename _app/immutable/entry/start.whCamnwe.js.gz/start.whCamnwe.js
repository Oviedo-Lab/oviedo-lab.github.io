import{a as t}from"../chunks/entry.ckO3O-_t.js";export{t as start};
