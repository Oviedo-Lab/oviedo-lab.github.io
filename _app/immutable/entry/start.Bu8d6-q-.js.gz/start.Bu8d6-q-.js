import{a as t}from"../chunks/entry.C6qtC0ne.js";export{t as start};
