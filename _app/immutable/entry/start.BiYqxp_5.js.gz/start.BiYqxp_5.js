import{a as t}from"../chunks/entry.CBPibkRy.js";export{t as start};
