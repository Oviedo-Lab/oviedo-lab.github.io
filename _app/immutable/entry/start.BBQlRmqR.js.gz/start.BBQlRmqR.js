import{a as t}from"../chunks/entry.C4XbsY3i.js";export{t as start};
